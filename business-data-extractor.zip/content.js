chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "extractData") {
    try {
      const data = extractPageData();
      sendResponse({ success: true, data });
    } catch (error) {
      sendResponse({ success: false, error: error.message });
    }
  }
  return true; // Keep the message channel open for async response
});

function extractPageData() {
  const url = window.location.href;
  
  // 1. Company Name Extraction
  // Fallbacks: og:site_name, <title>, <h1> text
  let companyName = '';
  const ogSiteName = document.querySelector('meta[property="og:site_name"]');
  if (ogSiteName) {
    companyName = ogSiteName.content;
  } else {
    companyName = document.title.split('-')[0].split('|')[0].trim();
    if (!companyName || companyName.length > 50) {
      const h1 = document.querySelector('h1');
      if (h1) companyName = h1.innerText.trim();
    }
  }

  // 2. Email Extraction
  const emailRegex = /([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/gi;
  const emails = new Set();
  // We extract from document.body.innerText. Note: This can be heavy on very large pages, 
  // but it's effective. Alternatively, we could extract from anchor tags `mailto:`.
  const pageText = document.body.innerText;
  
  let match;
  while ((match = emailRegex.exec(pageText)) !== null) {
    // Basic filter to avoid common false positives like "image@2x.png"
    if (!match[1].endsWith('.png') && !match[1].endsWith('.jpg') && !match[1].endsWith('.jpeg')) {
        emails.add(match[1].toLowerCase());
    }
  }
  
  // Look for mailto links as well
  const mailtoLinks = document.querySelectorAll('a[href^="mailto:"]');
  mailtoLinks.forEach(link => {
      const email = link.href.replace('mailto:', '').split('?')[0];
      if (email && email.includes('@')) {
          emails.add(email.toLowerCase());
      }
  });

  // 3. Phone Extraction
  // A generic international phone regex
  const phoneRegex = /(?:\+?\d{1,3}[\s-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/g;
  const phones = new Set();
  
  // Look for tel links
  const telLinks = document.querySelectorAll('a[href^="tel:"]');
  telLinks.forEach(link => {
      const phone = link.href.replace('tel:', '').trim();
      if (phone) {
          phones.add(phone);
      }
  });

  // Extract from text as fallback
  if (phones.size === 0) {
    let pMatch;
    while ((pMatch = phoneRegex.exec(pageText)) !== null) {
        phones.add(pMatch[0].trim());
    }
  }

  return {
    url,
    companyName,
    emails: Array.from(emails).slice(0, 5), // take up to 5 emails
    phones: Array.from(phones).slice(0, 5)  // take up to 5 phones
  };
}
